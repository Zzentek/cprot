import DiscordPricingSection from '../discord/DiscordPricingSection';
import FeaturesSection from "../CaracteristicasMC"
import FAQSection from "../FAQSection"
import Footer from "../Footer"
import Navbar from "../Navbar";
import PanelShowcase from "../PanelShowcase"
import LocationsSection from '../LocationsSection';
import CaracteristicasMC from '../CaracteristicasMC';

export default function DiscordPage() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#0a0b0f] transition-colors duration-300">
      <Navbar />
      <DiscordPricingSection />
      <CaracteristicasMC />
      <LocationsSection />
      <FAQSection />
      <PanelShowcase />
      <Footer />
    </div>
  );
}
